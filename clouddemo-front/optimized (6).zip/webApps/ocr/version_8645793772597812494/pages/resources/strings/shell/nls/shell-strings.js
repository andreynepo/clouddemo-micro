define(function() {
  'use strict';

  return {
  "root" : true
};
});